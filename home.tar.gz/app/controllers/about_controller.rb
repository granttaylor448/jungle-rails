class AboutController < ApplicationController
  def show
  end
end
