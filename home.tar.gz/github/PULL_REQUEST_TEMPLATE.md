Note to students:
-----------------

You *don't* need to submit pull requests (PRs) for your solutions. We don't want to merge your changes! Our version stays unsolved for future students to fork.

When you've completed the project, just submit your repo URL in Compass for evaluation.
